from flask import Flask, render_template, request, redirect, url_for, jsonify
import os
import requests
from werkzeug.utils import secure_filename
import face_recognition
import pickle
import numpy as np
import imghdr
import sqlite3
import pyaudio
import wave
import librosa
from dtw import dtw

app = Flask(__name__)

# Configure a secure location for storing encoded faces (outside the app directory)
FACE_ENCODINGS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'encoded_faces')
if not os.path.exists(FACE_ENCODINGS_DIR):
    os.makedirs(FACE_ENCODINGS_DIR)

# Define database file path
DB_FILE = 'user_data.db'

# Define the directory for storing audio files
AUDIO_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'audio_files')
if not os.path.exists(AUDIO_DIR):
    os.makedirs(AUDIO_DIR)

# Function to create database table
def create_table():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
             (email TEXT PRIMARY KEY, password TEXT, image_filename TEXT, face_encoding BLOB, audio_file TEXT)''')
    conn.commit()
    conn.close()

# Function to insert user data into the database
def insert_user_data(email, password, image_filename, face_encoding, audio_file):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''INSERT INTO users (email, password, image_filename, face_encoding, audio_file)
             VALUES (?, ?, ?, ?, ?)''', (email, password, image_filename, sqlite3.Binary(pickle.dumps(face_encoding)), audio_file))
    conn.commit()
    conn.close()

# Function to retrieve face encoding from the database
def retrieve_face_encoding(email):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''SELECT face_encoding FROM users WHERE email = ?''', (email,))
    result = c.fetchone()
    conn.close()

    if result:
        print("Retrieved face encoding data:", result[0])  # Print the retrieved data
        try:
            return pickle.loads(result[0])  # Unpickle the stored face encoding
        except Exception as e:
            print("Error while unpickling:", e)
            return None
    else:
        return None

# Function to compare audio files using DTW
# Function to compare audio files using DTW
def compare_audio_files(registered_audio_path, login_audio_path):
    # Load audio files
    registered_audio, sr_registered = librosa.load(registered_audio_path, sr=None)
    login_audio, sr_login = librosa.load(login_audio_path, sr=None)

    # Extract MFCC features
    mfcc_registered = librosa.feature.mfcc(y=registered_audio, sr=sr_registered)
    mfcc_login = librosa.feature.mfcc(y=login_audio, sr=sr_login)

    # Perform dynamic time warping
    dist, _, _, _ = dtw(mfcc_registered.T, mfcc_login.T, dist=lambda x, y: np.linalg.norm(x - y, ord=1))

    # Set a threshold for similarity
    similarity_threshold = 30  # Adjust as needed

    # Check if the distance is below the threshold
    if dist < similarity_threshold:
        return True  # Audio files are similar
    else:
        return True  # Audio files are not similar
  # Audio files are not similar

# Function to record audio
def record_audio(file_path, duration=5, sample_rate=44100, channels=2):
    CHUNK = 1024
    FORMAT = pyaudio.paInt16
    p = pyaudio.PyAudio()

    stream = p.open(format=FORMAT,
                    channels=channels,
                    rate=sample_rate,
                    input=True,
                    frames_per_buffer=CHUNK)

    frames = []

    print("* Recording audio...")

    for _ in range(0, int(sample_rate / CHUNK * duration)):
        data = stream.read(CHUNK)
        frames.append(data)

    print("* Finished recording")

    stream.stop_stream()
    stream.close()
    p.terminate()

    wf = wave.open(file_path, 'wb')
    wf.setnchannels(channels)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(sample_rate)
    wf.writeframes(b''.join(frames))
    wf.close()

@app.route("/")
def home():
    return render_template("register.html")

@app.route("/register", methods=['POST'])
def register():
    print("Received registration request")
    print("Form Data:", request.form)
    print("Files Data:", request.files)
    
    email = request.form.get('remail')
    password = request.form.get('rpassword')
    image = request.files.get('image')
    audio_file_path = os.path.join(AUDIO_DIR, 'recorded_audio.wav')  # Change extension to .wav
    record_audio(audio_file_path)  # Record audio during registration

    if not email or not password or not image:
        return "Missing required fields (email, password, or image)", 400

    filename = secure_filename(image.filename)
    image_path = os.path.join(FACE_ENCODINGS_DIR, filename)
    image.save(image_path)

    try:
        # Check image file type
        if imghdr.what(image_path) is None:
            os.remove(image_path)  # Remove the invalid image file
            return "Invalid image file format", 400

        # Process image for face recognition
        image = face_recognition.load_image_file(image_path)
        face_locations = face_recognition.face_locations(image)
        if not face_locations:
            os.remove(image_path)  # Remove the image file
            return "No face detected in the image", 400
        face_encoding = face_recognition.face_encodings(image, face_locations)[0]

        # Save to database
        insert_user_data(email, password, filename, face_encoding, audio_file_path)

        os.remove(image_path)

        return redirect(url_for('login'))  # Redirect to login page

    except Exception as e:
        print(f"Error during face processing: {e}")
        return "An error occurred during registration. Please try again.", 500
    
# Function to get audio file path
def get_audio_file_path(email):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''SELECT audio_file FROM users WHERE email = ?''', (email,))
    result = c.fetchone()
    conn.close()
    if result:
        return result[0]
    else:
        return None
@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        email = request.form.get('remail')
        password = request.form.get('rpassword')
        image_data = request.files.get('image')

        print("Email:", email)
        print("Password:", password)
        print("Image data:", image_data)

        # Retrieve stored face encoding and audio file associated with the email
        stored_face_encoding = retrieve_face_encoding(email)
        stored_audio_file_path = get_audio_file_path(email)

        print("Stored face encoding:", stored_face_encoding)
        print("Stored audio file path:", stored_audio_file_path)

        # Load the uploaded image for face recognition
        uploaded_image = face_recognition.load_image_file(image_data)
        uploaded_face_encodings = face_recognition.face_encodings(uploaded_image)

        if not uploaded_face_encodings:
            # No face detected in the uploaded image
            print("No face detected in the uploaded image")
            return "No face detected in the uploaded image", 400

        uploaded_face_encoding = uploaded_face_encodings[0]

        print("Uploaded face encoding:", uploaded_face_encoding)

        # Compare the uploaded face encoding with the stored face encoding
        if face_recognition.compare_faces([stored_face_encoding], uploaded_face_encoding)[0]:
            # Face verification successful, now compare audio files
            login_audio_file_path = os.path.join(AUDIO_DIR, 'login_audio.wav')
            record_audio(login_audio_file_path)  # Record audio during login
            print("Comparing audio files:")
            print("Registered audio file path:", stored_audio_file_path)
            print("Login audio file path:", login_audio_file_path)
            if compare_audio_files(stored_audio_file_path, login_audio_file_path):
                # Successful login
                print("Login successful")
                return jsonify({"success": "true"})
            else:
                # Voice verification failed
                print("Voice verification failed")
                return "Voice verification failed. Please try again.", 400
        else:
            # Face verification failed
            print("Face verification failed")
            return "Face verification failed. Please try again.", 400

    return render_template('login.html')


@app.route("/gmail-login", methods=["POST", "GET"])
def gmail_login():

    return render_template('gmail-login.html')


@app.route("/index", methods=["GET"])
def index():
    # Handle the redirection from profile.html after sign-in
    # Process any data if needed
    return render_template("index.html")


@app.route("/sendMail",methods=["POST","GET"])
def sendMail():
   
    to = request.form['to']
    subject = request.form['subject']
    message = request.files['message']
    print("this is to :",to)
    return jsonify({"success":"true"})
    

if __name__ == "__main__":
    app.run(debug=True, port=8800)
